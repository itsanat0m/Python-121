#M7 Project
#Adam Mikkelsen
#2/27/24

import functions

def main():
    reg = functions.makeReg()
    students = functions.createInstance(reg)
    num = functions.menu()

    while num != 5:
        if num == 1:
            functions.writeInstance(students)
        elif num == 2:
            functions.getCourse(students)
        elif num  == 3:
            functions.getMajor(students)
        elif num == 4:
            functions.lookID(students)
        else:
            print('Invalid Input! Try Again!')

        num = functions.menu()

if __name__ == '__main__':
    main()
