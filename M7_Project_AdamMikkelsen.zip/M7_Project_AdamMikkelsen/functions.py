class Student:
    def __init__(self, stuID, firstName, lastName, major, courses):
        self.stuID = stuID
        self.firstName = firstName
        self.lastName = lastName
        self.major = major
        self.courses = courses
        self.email = f'{lastName}{stuID[-2:]}@student.faytechcc.edu'
    def __repr__(self):
        return (f'{self.stuID:<12}{(self.firstName + " " + self.lastName):<25}{self.major:<20}{self.email:<20}')

    def getID(self):
        return self.stuID
    def getFName(self):
        return self.firstName
    def getLName(self):
        return self.lastName
    def getMajor(self):
        return self.major
    def getCourses(self):
        return self.courses
    def getEmail(self):
        return self.email


def makeReg():
    stuReg = [ {"stuID":"1201", 'firstName':'Sarah', 'lastName':'Spadling', 'major':'Programming', 'courses':["MAT143-Math","ENG111-English","CIS115-Intro to Programming","CSC121-Python"]},

               {"stuID":"1202", 'firstName':'James', 'lastName':'Spalding', 'major':'Psychology', 'courses':["MAT243-Math","ENG211-English","PSY101-Intro to Psychology","ETH101-Intro to Ethics"]},

               {"stuID":"1203", 'firstName':'John', 'lastName':'Spalding', 'major':'Programming', 'courses':["MAT143-Math","ENG111-English","CIS115-Intro to Programming","CSC121-Python"]},

               {"stuID":"1204", 'firstName':'Rayliee', 'lastName':'Craston', 'major':'Biology', 'courses':["MAT143-Math","ENG111-English","BIO101-Intro to Biology","ICE101-Ice Skating"]},

               {"stuID":"1205", 'firstName':'Carter', 'lastName':'Craston', 'major':'Chemistry', 'courses':["MAT343-Math","ENG211-English","ETH101-Intro to Ethics","HIS201-American History"]},

               {"stuID":"1206", 'firstName':'Brodiey', 'lastName':'Craston', 'major':'Physics', 'courses':["MAT143-Math","ENG111-English","PHY101-Intro to Physics","ICE101-Ice Skating"]},

               {"stuID":"1207", 'firstName':'Caera', 'lastName':'Mikkelsen', 'major':'Art History', 'courses':["MAT243-Math","ENG211-English","HIS168-Religious History","HIS190-Intro to Art History"]},

               {"stuID":"1208", 'firstName':'Sophiah', 'lastName':'Mikkelsen', 'major':'Economics', 'courses':["MAT143-Math","ENG111-English","ETH101-Intro to Ethics","BUS121-Market Basics"]},

               {"stuID":"1209", 'firstName':'Scott', 'lastName':'Scott', 'major':'Programming', 'courses':["MAT143-Math","ENG111-English","CIS115-Intro to Programming","CSC121-Python"]},

               {"stuID":"1301", 'firstName':'Sean', 'lastName':'Lean', 'major':'Education', 'courses':["MAT343-Math","ENG311-English","ETH101-Intro to Ethics","EDU201-Adolescent Education"]},

               {"stuID":"1302", 'firstName':'Emily', 'lastName':'Mikkelsen', 'major':'Graphic Design', 'courses':["ART320-Botanical Design","ASB353-Death and Dying","GRA323-Technology for Design","GRA345-Design Rhetoric"]},

               {"stuID":"1303", 'firstName':'Porter', 'lastName':'Parker', 'major':'Psychology', 'courses':["MAT143-Math","ENG111-English","PSY101-Intro to Psychology","ETH101-Intro to Ethics"]},

               {"stuID":"1304", 'firstName':'Crete', 'lastName':'Crate', 'major':'Occult Studies', 'courses':["MAT143-Math","ENG111-English","ETH101-Intro to Ethics","HIS168-Religious History"]},

               {"stuID":"1305", 'firstName':'Parker', 'lastName':'Peter', 'major':'Education', 'courses':["MAT243-Math","ENG211-English","ETH101-Intro to Ethics","EDU201-Adolescent Education"]},

               {"stuID":"1306", 'firstName':'Orhum', 'lastName':'Sorhum', 'major':'Programming', 'courses':["MAT343-Math","ENG211-English","CIS215-Advanced Programming","CSC221-Advanced Python"]},

               {"stuID":"1307", 'firstName':'Durham', 'lastName':'Sorhum', 'major':'Culinary Arts', 'courses':["MAT143-Math","ENG211-English","CUL201-Sous Basics","CUL221-Kitchen Cleaning"]},

               {"stuID":"1308", 'firstName':'Werhum', 'lastName':'Sorhum', 'major':'Business', 'courses':["MAT243-Math","ENG211-English","ETH101-Intro to Ethics","BUS221-Market Practices"]},

               {"stuID":"1309", 'firstName':'Merhum', 'lastName':'Sorhum', 'major':'Politics', 'courses':["MAT243-Math","ENG211-English","ETH101-Intro to Ethics","HIS201-American History"]},

               {"stuID":"1401", 'firstName':'Lerhum', 'lastName':'Sorhum', 'major':'Programming', 'courses':["MAT243-Math","ENG211-English","CIS215-Advanced Programming","CSC221-Advanced Python"]},

               {"stuID":"1402", 'firstName':'Seurem', 'lastName':'Sorhum', 'major':'Engineering', 'courses':["MAT343-Math","ENG211-English","ETH101-Intro to Ethics","EGI321-Mechanical Engineering"]}
               ]
    return stuReg

def menu():
    print()
    print('Menu----------------')
    print('1) Display Registry Content')
    print('2) Display Course Roster')
    print('3) List of Students by Major')
    print('4) Student Search by Id')
    print('5) Exit')
    print('--------------------')
    choice = int(input('Enter a number to choose: '))
    return choice

def createInstance(reg):
    students = []
    for person in reg:
        stu = Student(person['stuID'],person['firstName'],person['lastName'],person['major'],person['courses'])
        students.append(stu)
    return students

def writeInstance(students):
    with open('studentRegistry.csv', 'w') as file:
        file.write('Student ID  Student Name             Student Major       Student Email\n')
        file.write('-------------------------------------------------------------------------------------\n')
        for person in students:
            sID = person.getID()
            fName = person.getFName()
            lName = person.getLName()
            major = person.getMajor()
            email = person.getEmail()
            file.write(f'{sID:<12}{fName + " " + lName:<25}{major:<20}{email:<20}\n')

def getCourse(students):
    courseWant = input('What course would like you look up? ')
    inCourse = []
    for student in students:
        courses = student.getCourses()
        for course in courses:
            if course == courseWant:
                inCourse.append(student)
    print()
    print('Student ID  Student Name             Student Major       Student Email')
    print('----------------------------------------------------------------------------------------------')
    for student in inCourse:
        print(repr(student))

def getMajor(students):
    majorWant = input('What major would like you look up? ')
    inMajor = []
    for stu in students:
        major = stu.getMajor()
        if major == majorWant:
            inMajor.append(stu)
    print()
    print('Student ID  Student Name             Student Major       Student Email')
    print('----------------------------------------------------------------------------------------------')
    for student in inMajor:
        print(repr(student))

def lookID(students):
    idWant = input('What ID would you like to look up? ')
    for stu in students:
        sID = stu.getID()
        if sID == idWant:
            print()
            print('Student ID  Student Name             Student Major       Student Email')
            print('----------------------------------------------------------------------------------------------')
            print(repr(stu))
