#functions for M2 Lab 1

#input function
def getInputs():
    repeat = 'y'
    while repeat == 'y':
        peopleRate = input('Enter arrival rate (customers/hour): ')
        atmRate = input('Enter service rate (customers/hour): ')
        #isNum = checkNum(peopleRate, atmRate)
        try:
            peopleRate = float(peopleRate)
            atmRate = float(atmRate)
            repeat = 'n'
        except:
            print('Incorrect Entry. Please enter a number.\n')

    return peopleRate, atmRate

#wait time calculation function
def calcWaitTime(peopleRate, atmRate):
    waitTime = (1/(atmRate - peopleRate)) - (1/atmRate)
    waitTime = waitTime * 60
    return waitTime

#printing results function
def displayResult(waitTime):
    print(f'Average wait time = {waitTime:.1f} minutes')

