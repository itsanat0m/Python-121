# Calculate wait time
# 01/23/24
# CSC121 M2Lab– Function Review
# Adam Mikkelsen

# pseudocode
#display menu
#get number of customers
#get work rate of atm
#calc waiting time per customer
#convert time to minutes
#print results
import waitTimeFunc

CALC_WAIT_CHOICE = '1'
EXIT_CHOICE = '2'

def display_menu():
    print('-------------------------')
    print('(1) Calculate Wait Time')
    print('(2) Exit Program')
    print('-------------------------')
    print()

def main():
    choice = 0
    while choice != EXIT_CHOICE:
        display_menu()
        choice = input('Enter your choice: ')
        if choice == CALC_WAIT_CHOICE:
            peopleRate, atmRate = waitTimeFunc.getInputs()
            waitTime = float(waitTimeFunc.calcWaitTime(peopleRate, atmRate))
            waitTimeFunc.displayResult(waitTime)
        elif choice == EXIT_CHOICE:
            break
        else:
            print('Incorrect Entry. Please try again.')
            print()
            


if __name__ == "__main__":
    main()

