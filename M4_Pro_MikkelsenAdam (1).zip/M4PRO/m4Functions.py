def makeReg():
    stuReg = [ {"stuID":"1201", 'firstName':'Sarah', 'lastName':'Spadling', 'major':'Programming', 'courses':["MAT143-Math","ENG111-English","CIS115-Intro to Programming","CSC121-Python"]},

               {"stuID":"1202", 'firstName':'James', 'lastName':'Spalding', 'major':'Psychology', 'courses':["MAT243-Math","ENG211-English","PSY101-Intro to Psychology","ETH101-Intro to Ethics"]},

               {"stuID":"1203", 'firstName':'John', 'lastName':'Spalding', 'major':'Programming', 'courses':["MAT143-Math","ENG111-English","CIS115-Intro to Programming","CSC121-Python"]},

               {"stuID":"1204", 'firstName':'Rayliee', 'lastName':'Craston', 'major':'Biology', 'courses':["MAT143-Math","ENG111-English","BIO101-Intro to Biology","ICE101-Ice Skating"]},

               {"stuID":"1205", 'firstName':'Carter', 'lastName':'Craston', 'major':'Chemistry', 'courses':["MAT343-Math","ENG211-English","ETH101-Intro to Ethics","HIS201-American History"]},

               {"stuID":"1206", 'firstName':'Brodiey', 'lastName':'Craston', 'major':'Physics', 'courses':["MAT143-Math","ENG111-English","PHY101-Intro to Physics","ICE101-Ice Skating"]},

               {"stuID":"1207", 'firstName':'Caera', 'lastName':'Mikkelsen', 'major':'Art History', 'courses':["MAT243-Math","ENG211-English","HIS168-Religious History","HIS190-Intro to Art History"]},

               {"stuID":"1208", 'firstName':'Sophiah', 'lastName':'Mikkelsen', 'major':'Economics', 'courses':["MAT143-Math","ENG111-English","ETH101-Intro to Ethics","BUS121-Market Basics"]},

               {"stuID":"1209", 'firstName':'Scott', 'lastName':'Scott', 'major':'Programming', 'courses':["MAT143-Math","ENG111-English","CIS115-Intro to Programming","CSC121-Python"]},

               {"stuID":"1301", 'firstName':'Sean', 'lastName':'Lean', 'major':'Education', 'courses':["MAT343-Math","ENG311-English","ETH101-Intro to Ethics","EDU201-Adolescent Education"]},

               {"stuID":"1302", 'firstName':'Emily', 'lastName':'Mikkelsen', 'major':'Graphic Design', 'courses':["ART320-Botanical Design","ASB353-Death and Dying","GRA323-Technology for Design","GRA345-Design Rhetoric"]},

               {"stuID":"1303", 'firstName':'Porter', 'lastName':'Parker', 'major':'Psychology', 'courses':["MAT143-Math","ENG111-English","PSY101-Intro to Psychology","ETH101-Intro to Ethics"]},

               {"stuID":"1304", 'firstName':'Crete', 'lastName':'Crate', 'major':'Occult Studies', 'courses':["MAT143-Math","ENG111-English","ETH101-Intro to Ethics","HIS168-Religious History"]},

               {"stuID":"1305", 'firstName':'Parker', 'lastName':'Peter', 'major':'Education', 'courses':["MAT243-Math","ENG211-English","ETH101-Intro to Ethics","EDU201-Adolescent Education"]},

               {"stuID":"1306", 'firstName':'Orhum', 'lastName':'Sorhum', 'major':'Programming', 'courses':["MAT343-Math","ENG211-English","CIS215-Advanced Programming","CSC221-Advanced Python"]},

               {"stuID":"1307", 'firstName':'Durham', 'lastName':'Sorhum', 'major':'Culinary Arts', 'courses':["MAT143-Math","ENG211-English","CUL201-Sous Basics","CUL221-Kitchen Cleaning"]},

               {"stuID":"1308", 'firstName':'Werhum', 'lastName':'Sorhum', 'major':'Business', 'courses':["MAT243-Math","ENG211-English","ETH101-Intro to Ethics","BUS221-Market Practices"]},

               {"stuID":"1309", 'firstName':'Merhum', 'lastName':'Sorhum', 'major':'Politics', 'courses':["MAT243-Math","ENG211-English","ETH101-Intro to Ethics","HIS201-American History"]},

               {"stuID":"1401", 'firstName':'Lerhum', 'lastName':'Sorhum', 'major':'Programming', 'courses':["MAT243-Math","ENG211-English","CIS215-Advanced Programming","CSC221-Advanced Python"]},

               {"stuID":"1402", 'firstName':'Seurem', 'lastName':'Sorhum', 'major':'Engineering', 'courses':["MAT343-Math","ENG211-English","ETH101-Intro to Ethics","EGI321-Mechanical Engineering"]}
               ]
    return stuReg

def menu():
    print()
    print('Menu----------------')
    print('1) Display Registry Content')
    print('2) Display Course Roster')
    print('3) List of Students by Major')
    print('4) Student Search by Id')
    print('5) Exit')
    print('--------------------')
    choice = int(input('Enter a number to choose: '))
    
    return choice

def displayReg(reg):
    print()
    print('Stu ID    First Name     Last Name      Major          Course')
    print('----------------------------------------------------------------')
    for person in reg:
        for course in (person['courses']):
            print(f'{person["stuID"]:<10}{person["firstName"]:<15}{person["lastName"]:<15}{person["major"]:<15}', course)

def getCourse(reg):
    courseWant = input('What course would you like to look up: ')
    roster = []
    for person in reg:
        for course in (person['courses']):
            if course == courseWant:
                roster.append({'stuID':person['stuID'],'firstName':person['firstName'],'lastName':person['lastName'], 'major':person['major']})
    return roster

def displayCourseRoster(roster):
    print()
    print('Stu ID    First Name     Last Name      Major')
    print('-----------------------------------------------')
    for person in roster:
         print(f'{person["stuID"]:<10}{person["firstName"]:<15}{person["lastName"]:<15}{person["major"]}')

def getMajor(reg):
    majorWant = input('What major would you like to look up: ')
    roster = []
    for person in reg:
            if person['major'] == majorWant:
                roster.append({'stuID':person['stuID'],'firstName':person['firstName'],'lastName':person['lastName']})
    return roster

def displayMajor(roster):
    print()
    print('Stu ID    First Name     Last Name')
    print('------------------------------------')
    for person in roster:
        print(f'{person["stuID"]:<10}{person["firstName"]:<15}{person["lastName"]:<15}')

def lookupID(reg):
    i = 0
    while 1 < 10:
        idWant = input('What ID would you like to look up: ')
        student = []
        for person in reg:
            if person['stuID'] == idWant:
                return person
        print('Invalid ID. Try Again')
        i += 1
    

def displayIDLookup(person):
    print()
    print('Stu ID    First Name     Last Name      Major')
    print('-----------------------------------------------')
    print(f'{person["stuID"]:<10}{person["firstName"]:<15}{person["lastName"]:<15}{person["major"]}')
                
                      

        
