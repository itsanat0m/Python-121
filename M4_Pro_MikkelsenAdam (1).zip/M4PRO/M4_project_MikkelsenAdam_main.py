#M4 project
#Adam Mikkelsen
# 02/06/2024

# Student Registry

import m4Functions

def main():
    #import reg
    stuReg = m4Functions.makeReg()
    #menu
    stop = 'no'
    while stop != 'yes':
        menuChoice = m4Functions.menu()

        if menuChoice == 1:
            m4Functions.displayReg(stuReg)
        elif menuChoice == 2:
            roster = m4Functions.getCourse(stuReg)
            m4Functions.displayCourseRoster(roster)
        elif menuChoice == 3:
            majorRoster = m4Functions.getMajor(stuReg)
            m4Functions.displayMajor(majorRoster)
        elif menuChoice == 4:
            student = m4Functions.lookupID(stuReg)
            m4Functions.displayIDLookup(student)
        elif menuChoice == 5:
            stop = 'yes'
        else:
            print('Please enter a valid number. ')
        
        
        

if __name__ == '__main__':
    main()
