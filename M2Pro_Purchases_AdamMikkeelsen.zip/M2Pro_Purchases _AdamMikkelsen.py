# Program to calculate costs of going to a store
# 01/25/24
# CSC-121 M2Pro - Purchases
# Adam Mikkelsen

# Pseudocode
#get item
#calculate item price
#ask for more items
#add items
#calc tax
#get total
#print totals

import proFunctions

def main():
    x = 1
    cont = int(input('How many items would you like to purchase? '))
    total = 0
    #calculate items
    while x <= cont:
        print(f'Item {x}')
        #get item info
        itemCost = proFunctions.getItems(x)
        #calc subtotal
        total += itemCost
        x += 1

    #get taxes and total
    tax, fullTot = proFunctions.calcTax(total)

    #display results
    proFunctions.displayResults(total, tax, fullTot)

if __name__== '__main__':
    main()
