#Functions for m2 lab 2

def calcCost(numItem, cost):
    totCost = numItem * cost
    return totCost

def getItems(x):
    numItem = int(input(f'Enter count of item {x}: '))
    cost = float(input(f'Enter cost for item {x}: '))
    totCost = calcCost(numItem, cost)
    print(f'The cost for item {x} is {totCost:.2f}')
    return totCost

def calcTax(subtotal):
    taxRate = float(input('Enter sales tax rate (%): '))
    taxRate = taxRate/100
    tax = float(subtotal * taxRate)

    fullTot = subtotal + tax
    return tax, fullTot

def displayResults(subtotal, tax, total):
    print(f'Total cost (pre-tax):   ${subtotal:.2f}')
    print(f'Sales tax:              ${tax:.2f}')
    print(f'Total cost (with tax):  ${total:.2f}')    
