def menu():
    print('-------------------------Menu---------------------------')
    print('1) Search by Team (list number of times and years won)')
    print('2) Search by Year')
    print('3) Get File Listing Number of Times Each Team Won')
    print('4) Exit')
    print('--------------------------------------------------------')
    print()
    choice = int(input('Enter Choice: '))
    return choice

def getList(file):
    txt = file.readlines()
    lines = []
    for item in txt:
        item = item.rstrip('\n')
        item = item.split(',')
        lines.append(item)
    lines.remove(lines[0])
    return lines

def findTeam(winners):
    toFind = input("What Team Would You Like to Look Up? ")
    toFind = toFind.lower()
    found = ''
    for item in winners:
        if item[1] == toFind:
            found += f'{item[0]}, '
    print('Team : ' , toFind.title())
    print('Years won: ' + found.rstrip(', '))
    
def getYear(winners):
    toFind = input('What Year Would You Like to Look Up? ')
    if len(toFind) == 4:
        for item in winners:
            if item[0] == toFind:
                team = item[1]
        try:
            print('In the Year ' + toFind +' , the ' + team.title() + ' Won the World Series')
        except:
            print('No One Won the World Series This Year!')
    else:
        print('Please Enter a Valid Year')

def timesWon(winners):
    teams = []
    for item in winners:
        teams.append(item[1])
    winnerTeams = []
    for team in teams:
        teamWon = f'{team}: '
        for item in winners:
            if item[1] == team:
                teamWon += f'{item[0]}, '
        teamWon = teamWon.rstrip(', ')
        if teamWon not in winnerTeams:
            winnerTeams.append(teamWon)
    with open('timesWon.txt', 'w') as file:
        for item in winnerTeams:
            file.write(item + '\n')
    print('\nFile Saved to Device!\n')
    
