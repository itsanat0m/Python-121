#M6 Project
#World Series Winners
#Adam Mikkelsen
#2/22/2024

import functions

def main():
    with open('WorldSeriesWinners.csv' , 'r') as file:
        winners = functions.getList(file)
    choice = functions.menu()
    while choice != 4:
        if choice == 1:
            functions.findTeam(winners)
        if choice == 2:
            functions.getYear(winners)
        if choice == 3:
            functions.timesWon(winners)
        choice = functions.menu()
        
                

if __name__ == "__main__":
    main()
