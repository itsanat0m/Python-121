#CSC-121 Final Project
#Adam Mikkelsen
#2/29/2024

import functions
import csv

def main():
    students = functions.getStu()
    choice = functions.menu()
    try:
        choice = int(choice)
    except:
        print('Entry must be a number! Please try again.')
        choice = functions.menu()

    #main function while
    while choice != 6:
        if choice == 1:
            functions.displayStu(students)
        elif choice == 2:
            students = functions.addStu(students)
        elif choice == 3:
            students = functions.delStu(students)
        elif choice == 4:
            functions.findLast(students)
        elif choice == 5:
            functions.findID(students)
        elif choice > 6 or choice < 1:
            print('Number is not a choice, please pick again!')

        # choice decision
        choice = functions.menu()
        try:
            choice = int(choice)
        except:
            print('Entry must be a number! Please try again.')
            choice = functions.menu()
        


    print('Good-Bye!')
    


if __name__ == '__main__':
    main()
