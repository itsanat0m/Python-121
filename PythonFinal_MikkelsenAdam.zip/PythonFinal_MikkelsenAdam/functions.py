import csv

class Student:
    def __init__(self, stuID, fName, lName, active = True):
        self.stuID = stuID
        self.fName = fName
        self.lName = lName
        self.login = self.setLogin()
        self.email = self.setEmail()
        self.active = active

    def __repr__(self):
        return f'{self.lName + ", " + self.fName:<20}{self.stuID:<15}{self.login:<15}{self.email}'

    #init funcs
    
    def setLogin(self):
        name5 = self.lName[:5]
        id3 = self.stuID[-3:]
        login = name5 + id3
        return login
    
    def setEmail(self):
        email = self.login + '@student.faytechcc.edu'
        return email
    
    def setActive(self, toChange):
        self.active = toChange

    #getters

    def getID(self):
        return self.studID
    def getFName(self):
        return self.fName
    def getLName(self):
        return self.lName
    def getLogin(self):
        return self.login
    def getEmail(self):
        return self.email
    def getActive(self):
        return self.active

    
    

def getStu():
    stu = []

    inactive = []
    with open('inactiveStudents.txt', 'r') as f:
        holder = f.readlines()
        for item in holder:
            inactive.append(item.split(','))
    inactive = inactive[0]
    with open('StudentInfo.csv', 'r') as file:
        reader = csv.reader(file, delimiter =',')
        for row in reader:
            currStu = Student(row[2],row[1], row[0])
            stu.append(currStu)
            if row[2] in inactive:
                currStu.active = False
    stu.remove(stu[0])
    return stu

def menu():
    print()
    print('--------------Menu-----------------------------------')
    print('1) Print List of Students (saves the display to a txt file)')
    print('2) Add New Student (requires first and last name, student ID')
    print('3) Delete a Student Record (set to inactive)')
    print('4) Search for Student by Last Name')
    print('5) Search for Student by ID')
    print('6) Exit')
    print()
    choice = input('Enter Choice: ')
    return choice

def displayStu(students):
    with open('students_accounts.txt', 'w') as file:
        file.write('Last, First         ID Num         Login ID       Email\n')
        file.write('-------------------------------------------------------------------------------------\n')
        for row in students:
            if row.active == True:
                file.write(repr(row) + '\n')
    print('File Saved to Device!')

def addStu(students):
    loops = True
    while loops == True:
        stuID = input('Enter New Student ID (Must be 8 digits): ')
        if len(stuID) == 8:
            loops = False
    last = input('Enter New Student Last Name: ')
    first = input('Enter New Student First Name: ')
    stu = [last,first,stuID]
    with open('StudentInfo.csv', 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(stu)
    toStu = Student(stuID, first, last)
    students.append(toStu)
    return students

def delStu(students):
    toDel = input('What Student Would You Like to Delete (Enter Student ID): ')
    for stu in students:
        if stu.stuID == toDel:
            stu.active = False
            with open('inactiveStudents.txt', 'a') as file:
                stuID = f',{stu.stuID}'
                file.write(stuID)
    return students

def findLast(students):
    print()
    toFind = input('What is the last name of the student you would like to look up?\n')
    inList = False
    for stu in students:
        if stu.lName == toFind:
            print(f'Student ID: {stu.stuID}  Name: {stu.fName} {stu.lName}  Login: {stu.login}  Email: {stu.email}')
            inList = True
    if inList == False:
        print('Student Does Not Exist.')
    inList = False
    print()
            

def findID(students):
    print()
    toFind = input('What is the student ID of the student you would like to look up?\n')
    inList = False
    for stu in students:
        if stu.stuID == toFind:
            print(f'Student ID: {stu.stuID}  Name: {stu.fName} {stu.lName}  Login: {stu.login}  Email: {stu.email}')
            inList = True
    if inList == False:
        print('Student Does Not Exist.')
    inList = False
    print()
























































    


