def calcInfected(sick, init):
    result = [init]
    for i in range(len(sick)):
        result.append(int(result[i] * sick[i]))
    result.pop(0)

    return result

def display(noVac, vac):
    print('Week     r=3     vaccine')
    for i in range(len(noVac)):
        print(f' {i + 1:<4}     {noVac[i]:<4}     {vac[i]}')

