# Virus spread calculator
# 02/01/2024
# CSC121 M3Pro– List
# Adam Mikkelsen

# get weeks and infection rate
# calc daily rate for each week
# print results

import functions

def main():
    initInfec = int(input('how many people are infected initially? '))
    noVacRate = [3,3,3,3,3,3,3,3]
    vacRate = [3,3,3,3,.8,.8,.8,.8]
    noVac = functions.calcInfected(noVacRate, initInfec)
    vac = functions.calcInfected(vacRate, initInfec)
    functions.display(noVac, vac)


if __name__ == "__main__":
    main()

