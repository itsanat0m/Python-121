# Sales History
# 2/15/2024
# CSC121 M5Pro
# Adam Mikkelsen

import functions

def main():
    choice = functions.menu()
    while choice != 5:
        if choice == 1:
            with open('sales.csv', 'r') as file:
                functions.readSales(file)
        elif choice == 2:
            with open('sales.csv', 'r') as file:
                num = functions.getNum(file)
            with open('sales.csv', 'a') as file:
                functions.addSales(file, num)
        elif choice == 3:
            with open('sales.csv','r') as file:
                functions.prodSales(file)
        elif choice == 4:
            with open('sales.csv','r') as file:
                cust = functions.custSales(file)
            with open('customerSales.txt', 'w') as file:
                functions.writeCust(file, cust)
                
        else:
            print('Invalid Choice! Try Again!')
            print()
        choice = functions.menu()


if __name__ == '__main__':
    main()
