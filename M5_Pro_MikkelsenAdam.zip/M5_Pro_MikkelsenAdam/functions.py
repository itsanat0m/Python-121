def menu():
    print('----------------MENU-------------------------')
    print('1) Read from existing list of transactions')
    print('2) Add new transactions to file')
    print('3) Display Total Sales for each Product')
    print('4) Display Total Units and Total Sales for each Customer')
    print('5) Exit')
    print('---------------------------------------------------')
    choice = int(input('Enter Choice: '))
    print()
    return choice

def readSales(file):
    txt = file.readlines()
    lines = []
    for item in txt:
        item = item.rstrip('\n')
        item = item.split(',')
        lines.append(item)
    print(f'{lines[0][0]:<3}{lines[0][1]:<10}{lines[0][2]:<7}{lines[0][3]:<7}{lines[0][4]:<7}{lines[0][5]:<7}')
    print('------------------------------------------------------')
    for line in lines:
        if line != lines[0]:
                print(f'{line[0]:<3}{line[1]:<12}{line[2]:<7}{line[3]:<7}{line[4]:<7}{line[5]:<7}')

def getNum(file):
    txt = file.readlines()
    lines = []
    for item in txt:
        item = item.rstrip('\n')
        item = item.split(',')
        lines.append(item)
    for item in lines:
        num = item[0]
    num =int(num) + 1
    print(num)
    return num

def addSales(file, num):
    date = input('Enter the date of purchase (?/?/????): ')
    prodId = input('Enter product ID: ')
    custId = input('Enter customer ID: ')
    units = int(input('Enter amount of units: '))
    price = float(input('Enter price per unit: '))
    toAdd = f'\n{num},{date},{prodId},{custId},{units},{price}'
    file.write(toAdd)

def prodSales(file):
    txt = file.readlines()
    lines = []
    for item in txt:
        item = item.rstrip('\n')
        item = item.split(',')
        lines.append(item)
    lines.remove(lines[0])
    prodIds = []
    prodSales = []
    prod = []
    for line in lines:
        if line[2] not in prodIds:
            prodIds.append(line[2])
    for line in lines:
        num = int(line[4]) * float(line[5])
        prodSales.append([line[2],num])
    for product in prodIds:
        prodTotal = float(0)
        for item in prodSales:
            if item[0] == product:
                prodTotal+= item[1]
        prod.append([product,prodTotal])
    print('Product ID   Total Sales')
    print('---------------------------')
    for item in prod:
        print(f'{item[0]:<13}${item[1]}')

def custSales(file):
    txt = file.readlines()
    lines = []
    for item in txt:
        item = item.rstrip('\n')
        item = item.split(',')
        lines.append(item)
    lines.remove(lines[0])
    custIds = []
    custSales = []
    for line in lines:
        if line[3] not in custIds:
            custIds.append(line[3])
    for cust in custIds:
        totalUnits = int(0)
        totalSales = float(0)
        for line in lines:
            if line[3] == cust:
                num = int(line[4]) * float(line[5])
                totalUnits += int(line[4])
                totalSales += num
        custSales.append([cust,totalUnits,totalSales])
    print('Customer ID   Total Units  Total Sales')
    print('----------------------------------------')
    for item in custSales:
        print(f'{item[0]:<14}{item[1]:<13}${item[2]}')
    return custSales

def writeCust(file, cust):
    file.write('Customer ID            Total Units Sold     Total Sales\n')
    file.write('--------------------------------------------------------\n')
    for item in cust:
        file.write(f'{item[0]:<23}{item[1]:<21}${item[2]}\n')
    









